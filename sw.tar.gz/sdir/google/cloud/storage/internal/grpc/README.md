# Google Cloud Storage gRPC Plugin implementation

This directory contains the implementation of the Google Cloud Storage gRPC
plugin. This plugin replaces the REST-based implementation of the C++ client
library with a gRPC-based implementation.
